import {useEffect,useLayoutEffect,useRef,useState,type CSSProperties,type ReactNode} from 'react';
import {Volume2,VolumeX,Sparkles,Pause,ChevronLeft,ChevronRight} from 'lucide-react';
import type {Card} from '../lib/meanings';
import {positions} from '../lib/meanings';

type Cue='deal'|'pick'|'reveal'|'page'|'portal';
let context:AudioContext|undefined, master:GainNode|undefined;
let enabled=false, ambience:OscillatorNode[]=[];
const soundKey='moonroom.sound.v1';
function audio(){
  if(!context){const Audio=window.AudioContext||(window as unknown as {webkitAudioContext:typeof AudioContext}).webkitAudioContext;if(!Audio)return;
    context=new Audio();master=context.createGain();master.gain.value=.2;master.connect(context.destination);}
  if(context.state==='suspended')void context.resume().catch(()=>{});
  return context;
}
function stopAmbience(){ambience.forEach(o=>{try{o.stop()}catch{}});ambience=[];}
function startAmbience(){const c=audio();if(!c||!master||ambience.length)return;
  [110,164.81,220.5].forEach((hz,i)=>{const o=c.createOscillator(),g=c.createGain();o.type='sine';o.frequency.value=hz;g.gain.setValueAtTime(0,c.currentTime);g.gain.linearRampToValueAtTime(.032/(i+1),c.currentTime+2);o.connect(g);g.connect(master!);o.onended=()=>{o.disconnect();g.disconnect()};o.start();ambience.push(o)});
}
export function chime(kind:Cue){if(!enabled||document.hidden)return;try{const c=audio();if(!c||!master)return;startAmbience();
  const notes:Record<Cue,number[]>={deal:[220,293.66,440],pick:[440,659.25],reveal:[329.63,493.88,659.25],page:[261.63,392],portal:[261.63,329.63,392,523.25,783.99]};
  notes[kind].forEach((hz,i)=>{const o=c.createOscillator(),g=c.createGain();const t=c.currentTime+i*.09;o.type='sine';o.frequency.setValueAtTime(hz,t);o.frequency.exponentialRampToValueAtTime(hz*1.003,t+.5);g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(.16,t+.02);g.gain.exponentialRampToValueAtTime(.001,t+1.1);o.connect(g);g.connect(master!);o.onended=()=>{o.disconnect();g.disconnect()};o.start(t);o.stop(t+1.2)});
  if(kind==='deal'||kind==='page'){const buffer=c.createBuffer(1,c.sampleRate*.4,c.sampleRate),data=buffer.getChannelData(0);for(let i=0;i<data.length;i++)data[i]=(Math.random()*2-1)*Math.sin(Math.PI*i/data.length)*.13;const source=c.createBufferSource(),filter=c.createBiquadFilter();filter.type='lowpass';filter.frequency.value=950;source.buffer=buffer;source.connect(filter);filter.connect(master);source.onended=()=>{source.disconnect();filter.disconnect()};source.start();}
}catch{/* Sound is optional; the reading stays usable if audio is unavailable. */}}

export function ExperienceControls({reduced,setReduced}:{reduced:boolean;setReduced:(v:boolean)=>void}){
  const [on,setOn]=useState(false),[audioError,setAudioError]=useState('');
  const systemReduced=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  useEffect(()=>{try{enabled=localStorage.getItem(soundKey)==='on';setOn(enabled)}catch{}
    const unlock=()=>{if(enabled)try{startAmbience()}catch{}};
    const visibility=()=>{document.documentElement.classList.toggle('moonroom-paused',document.hidden);if(document.hidden){void context?.suspend()}else if(enabled&&context)void context.resume().catch(()=>{});};
    window.addEventListener('pointerdown',unlock);window.addEventListener('keydown',unlock);document.addEventListener('visibilitychange',visibility);
    return()=>{window.removeEventListener('pointerdown',unlock);window.removeEventListener('keydown',unlock);document.removeEventListener('visibilitychange',visibility);stopAmbience();enabled=false;void context?.suspend()};
  },[]);
  const toggle=()=>{const next=!on;try{if(next){if(!audio())throw Error('unsupported');enabled=true;startAmbience();chime('reveal')}else{enabled=false;stopAmbience();void context?.suspend()}setOn(next);setAudioError('');try{localStorage.setItem(soundKey,next?'on':'off')}catch{}}catch{enabled=false;setOn(false);setAudioError('Trình duyệt này chưa bật được âm thanh.')}};
  return <div className="experience-controls"><button className="experience-button" aria-pressed={on} aria-label={on?'Tắt âm thanh huyền bí':'Bật âm thanh huyền bí'} onClick={toggle}>{on?<Volume2 size={17}/>:<VolumeX size={17}/>}<span>Âm thanh {on?'bật':'tắt'}</span></button><button className="experience-button motion-control" aria-pressed={reduced} disabled={systemReduced} title={systemReduced?'Đang giảm chuyển động theo cài đặt trợ năng của thiết bị':undefined} aria-label={systemReduced?'Giảm chuyển động theo thiết bị':reduced?'Bật hiệu ứng chuyển động':'Giảm hiệu ứng chuyển động'} onClick={()=>setReduced(!reduced)}>{reduced?<Pause size={15}/>:<Sparkles size={15}/>}<span>{systemReduced?'Theo thiết bị':reduced?'Chuyển động nhẹ':'Hiệu ứng'}</span></button>{audioError&&<span role="status" className="audio-error">{audioError}</span>}</div>
}
export function Atmosphere(){return <div className="atmosphere" aria-hidden="true"><div className="moon-haze"/>{Array.from({length:12},(_,i)=><i key={i} style={{'--x':`${(i*37+11)%100}%`,'--delay':`${-i*1.7}s`,'--duration':`${14+i%5*3}s`} as CSSProperties}/>)}</div>}

export function FlyingDeck({children,reduced}:{children:ReactNode;reduced:boolean}){
  const ref=useRef<HTMLDivElement>(null),[dealing,setDealing]=useState(!reduced);
  useLayoutEffect(()=>{const root=ref.current;if(!root)return;if(reduced||window.matchMedia('(prefers-reduced-motion: reduce)').matches){setDealing(false);return}let active=true;
    const cards=Array.from(root.querySelectorAll<HTMLElement>('.pick-card'));
    const table=root.getBoundingClientRect(),originX=table.left+table.width/2,originY=table.top+Math.min(table.height*.5,230);
    const geometry=cards.map(el=>{const r=el.getBoundingClientRect();return {el,x:originX-r.left-r.width/2,y:originY-r.top-r.height/2}});
    const animations=geometry.map(({el,x,y},i)=>el.animate([{transform:`translate3d(${x}px,${y}px,0) rotate(${(i%5-2)*2}deg) scale(.82)`,opacity:0},{opacity:1,offset:.16},{transform:'translate3d(0,0,0) rotate(0deg) scale(1)',opacity:1}],{duration:820,delay:i*9,easing:'cubic-bezier(.2,.75,.22,1)',fill:'backwards'}));
    Promise.all(animations.map(a=>a.finished.catch(()=>{}))).then(()=>{if(active)setDealing(false)});
    return()=>{active=false;animations.forEach(a=>a.cancel())};
  },[reduced]);
  return <div className="tarot-table"><div className="table-seal" aria-hidden="true">☽ ✧ ☾</div><p className="table-caption" role="status">{dealing?'Bộ bài đang trải ra trên bàn…':'Chạm vào những lá bài bạn muốn chọn'}</p><div className={'deck-grid '+(dealing?'is-dealing':'')} ref={ref} inert={dealing}>{children}</div></div>
}

function OracleScene(){return <div className="oracle-scene" aria-hidden="true"><div className="oracle-halo"/><svg viewBox="0 0 800 340" className="oracle-illustration"><defs><linearGradient id="robe" x1="0" y1="0" x2="1" y2="1"><stop stopColor="#354c43"/><stop offset=".5" stopColor="#182c29"/><stop offset="1" stopColor="#091612"/></linearGradient><linearGradient id="hood"><stop stopColor="#06100d"/><stop offset="1" stopColor="#101e1c"/></linearGradient><linearGradient id="paper" x2="0" y2="1"><stop stopColor="#dfcc9e"/><stop offset="1" stopColor="#8b744b"/></linearGradient><radialGradient id="bookglow"><stop stopColor="#f8d897" stopOpacity=".35"/><stop offset="1" stopColor="#f8d897" stopOpacity="0"/></radialGradient></defs>
  <ellipse cx="400" cy="291" rx="340" ry="42" fill="#06130e"/><circle cx="400" cy="151" r="123" fill="none" stroke="#c7ad7040"/><circle cx="400" cy="151" r="135" fill="none" stroke="#c7ad7020" strokeDasharray="2 10"/>
  <path d="M255 287 Q278 185 315 164 Q305 49 400 22 Q495 49 485 164 Q522 185 545 287Z" fill="url(#robe)" stroke="#75876c" strokeOpacity=".3"/>
  <path d="M337 150 Q327 70 400 46 Q473 70 463 150 L434 196 L365 196Z" fill="url(#hood)"/>
  <path d="M315 164 Q326 63 400 28 Q474 63 485 164 M337 149 Q329 76 400 47 Q471 76 463 149" fill="none" stroke="#c9b584" strokeOpacity=".5" strokeWidth="2"/>
  <path d="M343 159 Q359 204 400 225 Q441 204 457 159 M304 199 L335 262 M496 199 L465 262" fill="none" stroke="#8b9b7a" strokeOpacity=".28" strokeWidth="2"/>
  <path d="M391 47 L400 63 L409 47 M394 201 L400 213 L406 201 L400 189Z" fill="#b89e66"/><circle cx="400" cy="202" r="3" fill="#e8d7a1"/>
  <g className="oracle-hand hand-left"><path d="M280 246 Q312 232 345 252 L372 266 Q377 272 370 275 L342 265 Q324 277 301 268Z" fill="#9b8873"/><path d="M329 253 L358 268 M323 259 L350 272" fill="none" stroke="#61594c"/></g>
  <g className="oracle-hand hand-right"><path d="M520 246 Q488 232 455 252 L428 266 Q423 272 430 275 L458 265 Q476 277 499 268Z" fill="#9b8873"/><path d="M471 253 L442 268 M477 259 L450 272" fill="none" stroke="#61594c"/></g>
  <g className="scene-book"><path d="M230 283 L382 270 L400 282 L418 270 L570 283 L553 318 L400 328 L247 318Z" fill="#16271f" stroke="#b89e66" strokeWidth="2"/><path d="M245 275 Q320 250 400 281 Q480 250 555 275 L545 309 Q466 293 400 318 Q334 293 255 309Z" fill="url(#paper)"/><path d="M400 281 L400 318" stroke="#66583c" strokeWidth="3"/><path d="M268 281 Q326 270 377 286 M268 290 Q326 279 377 295 M423 286 Q476 270 532 281 M423 295 Q476 279 532 290" fill="none" stroke="#796543" strokeOpacity=".55"/><path className="turning-leaf" d="M400 316 Q433 255 520 252 L535 281 Q463 272 400 316Z" fill="#e5d3a8" stroke="#aa9060"/></g>
  <ellipse cx="400" cy="275" rx="190" ry="70" fill="url(#bookglow)"/>
  <g fill="#c6aa70"><path d="M169 293 L189 293 L185 231 L173 231Z"/><path d="M611 293 L631 293 L627 231 L615 231Z"/></g><g className="candle-flames" fill="#f0d39b"><path d="M179 231 Q164 220 179 199 Q194 220 179 231Z"/><path d="M621 231 Q606 220 621 199 Q636 220 621 231Z"/></g>
  <g className="book-runes" fill="#ead09a" fontFamily="Georgia" fontSize="22"><text x="345" y="239">✧</text><text x="439" y="213">☽</text><text x="391" y="256">✦</text></g>
  </svg><span className="oracle-caption">NGƯỜI GIỮ NHỮNG TRANG SÁCH</span></div>}

const invitations=["Ở vị trí hiện tại, hãy dùng chủ đề này để nhìn lại điều đang chiếm nhiều tâm trí hoặc năng lượng của bạn. Có phần nào khớp với trải nghiệm thực tế, và phần nào không?","Ở vị trí cần nhìn rõ, đây là lời mời xem thêm một khía cạnh có thể bạn chưa dành đủ sự chú ý. Bạn cần quan sát hoặc kiểm chứng điều gì trước khi kết luận?","Ở vị trí hướng đi, hãy xem đây như một khả năng để cân nhắc. Bạn có thể chọn một bước nhỏ phù hợp với hoàn cảnh, hoặc dành thêm thời gian trước khi hành động."];
export function Grimoire({selected}:{selected:Card[]}){
  const [page,setPage]=useState(0);const card=selected[page];
  if(!card)return null;
  const turn=(next:number)=>{if(next===page)return;setPage(next);chime('page')};
  return <section className="grimoire" aria-label="Sách giải nghĩa ba lá bài"><OracleScene/><div className="book-tabs" role="tablist" aria-label="Chọn trang giải nghĩa">{selected.map((c,i)=><button id={`book-tab-${i}`} key={c.id} role="tab" aria-selected={page===i} aria-controls="book-page" tabIndex={page===i?0:-1} onClick={()=>turn(i)} onKeyDown={e=>{let n=i;if(e.key==='ArrowRight')n=(i+1)%3;else if(e.key==='ArrowLeft')n=(i+2)%3;else if(e.key==='Home')n=0;else if(e.key==='End')n=2;else return;e.preventDefault();turn(n);document.getElementById(`book-tab-${n}`)?.focus()}}><span>0{i+1}</span>{positions[i]}</button>)}</div>
  <div id="book-page" role="tabpanel" aria-labelledby={`book-tab-${page}`} tabIndex={0} className="open-book"><div key={card.id} className="book-spread"><div className="book-portrait"><span className="book-ornament">✧ ☾ ✧</span><img src={card.image} alt={`${card.vn} — ${card.name}`} width="220" height="380"/><p>{card.keywords}</p><span className="book-folio">MOONROOM · {String(page+1).padStart(2,'0')}</span></div><article className="book-meaning"><span className="meaning-position">LÁ {page+1} · {positions[page]}</span><h2>{card.vn}</h2><span className="book-card-name">{card.name} · Chiều xuôi</span><p className="floating-words">{card.meaning}</p><p className="position-invitation floating-words">{invitations[page]}</p><div className="reflection floating-words"><span>MỘT CÂU HỎI ĐỂ SUY NGẪM</span><p>{card.question}</p></div></article></div></div>
  <div className="book-navigation"><button className="text-button" disabled={page===0} onClick={()=>turn(page-1)}><ChevronLeft size={17}/>Trang trước</button><span role="status" aria-live="polite">Trang {page+1} / 3</span><button className="text-button" disabled={page===2} onClick={()=>turn(page+1)}>Trang sau<ChevronRight size={17}/></button></div><p className="book-disclaimer">Những biểu tượng gợi mở, không phải lời tiên tri. Hãy giữ lại điều phù hợp với trải nghiệm của bạn.</p></section>
}

export function Portal({active}:{active:boolean}){return <div className={'magic-portal '+(active?'portal-active':'')} aria-hidden="true"><div className="portal-ring"/><div className="portal-ring inner"/><span className="portal-symbol">{active?'✦':'☾'}</span>{Array.from({length:8},(_,i)=><i key={i} style={{'--angle':`${i*45}deg`,'--delay':`${i*.04}s`} as CSSProperties}>✧</i>)}</div>}
