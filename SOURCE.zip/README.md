# Moonroom source 1.3

Yêu cầu Node.js 22.13+ (khuyến nghị Node 24).

```sh
npm ci
npm run dev
npm run build
```

Sau khi sửa, thay các file website trong repo bằng nội dung thư mục `dist/` vừa build. Giữ `.nojekyll`. Vite dùng base tương đối nên chạy được tại gốc hoặc dưới tên repo. Không sửa đường dẫn ảnh thành /cards/.

Nội dung giao diện: app/page.tsx và app/ai-companion.tsx.
Hiệu ứng, sách và Web Audio: app/magic.tsx. Giao diện hiệu ứng: app/magic.css (nạp sau globals.css).
Minh họa người giữ sách là SVG trong mã nguồn; âm thanh được tổng hợp tại trình duyệt, không cần tải thêm tài nguyên.
Nghĩa 78 lá: lib/meanings.ts. Hướng dẫn gửi AI: lib/handoff.ts.

Kiểm thử logic:
```sh
npx esbuild tests/core.test.ts tests/handoff.test.ts --bundle --platform=node --format=esm --outdir=test-output
node test-output/core.test.js
node test-output/handoff.test.js
```

Không cần biến môi trường hay API key. Không có backend. Nhật ký lưu tại trình duyệt. Thông tin nguồn ảnh ở public/card-attributions.json.
