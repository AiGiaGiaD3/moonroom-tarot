// Editorial Vietnamese interpretations, upright only. Reflective, not predictive.
const major = [
['Kẻ khờ','Khởi đầu · Cởi mở','Một bước chân ở mép vực gợi sự hồn nhiên và tinh thần thử nghiệm. Khởi đầu có giá trị khi đi cùng nhận biết rủi ro.','Bạn muốn thử điều gì, và cần chuẩn bị tối thiểu điều gì trước bước đầu?'],
['Nhà ảo thuật','Chủ động · Nguồn lực','Các dụng cụ trên bàn gợi khả năng biến ý tưởng thành hành động bằng những gì đã có. Sự tập trung giúp nguồn lực rời rạc trở nên hữu ích.','Nguồn lực nào bạn đang có mà chưa sử dụng?'],
['Nữ tư tế','Trực giác · Khoảng lặng','Bức màn và cuộn sách gợi phần thông tin chưa được mở ra. Chậm lại có thể giúp bạn nghe rõ cảm nhận, đồng thời phân biệt nó với điều đã được kiểm chứng.','Bạn đang cảm nhận điều gì, và cần biết thêm dữ kiện nào?'],
['Hoàng hậu','Nuôi dưỡng · Nảy nở','Khu vườn và lúa chín gợi sự chăm sóc, sáng tạo và điều kiện để phát triển. Điều đang lớn lên cần thời gian lẫn sự quan tâm cụ thể.','Điều gì trong đời bạn cần được chăm chút đều đặn hơn?'],
['Hoàng đế','Cấu trúc · Ranh giới','Ngai đá gợi sự ổn định, trách nhiệm và trật tự. Cấu trúc có thể bảo vệ bạn, nhưng cũng cần đủ linh hoạt trước thực tế.','Ranh giới hay nguyên tắc nào sẽ giúp bạn vững vàng hơn?'],
['Giáo hoàng','Truyền thống · Học hỏi','Người thầy và hai môn sinh gợi tri thức được truyền lại, cộng đồng và những niềm tin chung. Đây là dịp xem điều gì phù hợp với giá trị của chính bạn.','Bạn đang theo một nguyên tắc vì tin vào nó hay vì đã quen?'],
['Đôi tình nhân','Gắn kết · Lựa chọn','Hai nhân vật gợi sự gặp gỡ, khác biệt và lựa chọn có ý thức. Lá này thường mở câu chuyện về giá trị và cam kết, không chỉ tình yêu.','Lựa chọn nào phù hợp nhất với điều bạn thật sự coi trọng?'],
['Cỗ xe','Định hướng · Quyết tâm','Hai sinh vật trước cỗ xe gợi những lực kéo khác nhau. Tiến lên đòi hỏi một hướng đi rõ và khả năng điều hòa các ưu tiên.','Bạn đang muốn đi về đâu, và điều gì kéo bạn sang hướng khác?'],
['Sức mạnh','Kiên nhẫn · Can đảm','Người phụ nữ bên sư tử gợi sức mạnh của sự điềm tĩnh thay vì cưỡng ép. Can đảm có thể là ở lại với cảm xúc khó mà không để nó quyết định thay mình.','Bạn có thể đáp lại tình huống bằng sự vững vàng và mềm mại thế nào?'],
['Ẩn sĩ','Chiêm nghiệm · Tìm đường','Ngọn đèn trên đỉnh núi gợi khoảng lặng để tìm điều quan trọng. Một bước lùi có chủ đích giúp phân biệt tiếng nói của mình với kỳ vọng bên ngoài.','Bạn cần tạm gác tiếng ồn nào để nghe rõ chính mình?'],
['Bánh xe số phận','Chu kỳ · Thay đổi','Bánh xe gợi những nhịp thay đổi mà ta không kiểm soát hoàn toàn. Điều có thể chọn là cách chuẩn bị và thích nghi.','Phần nào đang đổi thay, và phần nào vẫn nằm trong tay bạn?'],
['Công lý','Công bằng · Trách nhiệm','Cán cân và thanh kiếm gợi việc cân nhắc bằng chứng, hệ quả và trách nhiệm. Cảm giác đúng cần được đặt bên cạnh những dữ kiện cụ thể.','Nếu nhìn cả hai phía, bạn còn thiếu thông tin nào?'],
['Người treo ngược','Tạm dừng · Đổi góc nhìn','Tư thế đảo ngược gợi khả năng nhìn sự việc theo cách khác. Một khoảng dừng có ích khi nó có chủ đích, không chỉ là trì hoãn.','Điều gì thay đổi nếu bạn thử nhìn tình huống từ phía còn lại?'],
['Cái chết','Khép lại · Chuyển hóa','Hình tượng kết thúc mở câu chuyện về sự chuyển tiếp và buông điều đã hết vai trò. Lá này không dự báo cái chết hay mất mát cụ thể.','Điều gì đã hoàn thành vai trò nhưng bạn vẫn đang giữ lại?'],
['Tiết độ','Điều hòa · Nhịp độ','Dòng nước giữa hai cốc gợi sự kết hợp và điều chỉnh từng chút. Cân bằng thường đến từ nhịp sống bền vững hơn là một giải pháp cực đoan.','Bạn có thể điều chỉnh nhỏ điều gì để bớt nghiêng về một phía?'],
['Ác quỷ','Ràng buộc · Nhận diện','Những sợi xích gợi thói quen, sức hút hoặc sự lệ thuộc. Lá bài mời nhận ra cái giá của một lựa chọn mà không phán xét người đang mắc kẹt.','Điều gì cho bạn dễ chịu trước mắt nhưng khiến bạn mất tự do về lâu dài?'],
['Tòa tháp','Đứt gãy · Nhìn lại','Tòa tháp bị sét đánh gợi lúc một cấu trúc hay giả định không còn đứng vững. Đây là biểu tượng để xem lại nền tảng, không phải dự báo tai họa.','Giả định nào cần được kiểm tra lại trước khi bạn xây tiếp?'],
['Ngôi sao','Hy vọng · Hồi phục','Nước được rót xuống đất và hồ gợi sự hồi phục, cho đi và nối lại niềm tin. Hy vọng có thể bắt đầu từ một việc nhỏ đủ sức làm hôm nay.','Điều gì giúp bạn lấy lại một chút niềm tin và năng lượng?'],
['Mặt trăng','Mơ hồ · Cảm nhận','Con đường dưới ánh trăng gợi vùng chưa rõ, nơi trí tưởng tượng có thể lấp chỗ trống. Cảm xúc đáng được lắng nghe, nhưng không tự động là bằng chứng.','Bạn biết chắc điều gì, và đang tự điền vào chỗ trống điều gì?'],
['Mặt trời','Sáng rõ · Niềm vui','Ánh nắng và đứa trẻ gợi sự cởi mở, sinh lực và niềm vui giản dị. Nhìn nhận điều đang tốt cũng quan trọng như tìm vấn đề cần sửa.','Điều gì đang đem lại sức sống mà bạn muốn dành thêm chỗ cho nó?'],
['Phán xét','Thức tỉnh · Nhìn lại','Tiếng kèn gợi một lời gọi nhìn lại và trả lời bằng lựa chọn mới. Sự nhận ra có ý nghĩa khi dẫn đến trách nhiệm với bước tiếp theo.','Sau những gì đã trải qua, bạn muốn trả lời khác đi điều gì?'],
['Thế giới','Hoàn tất · Kết nối','Vòng hoa gợi sự trọn vẹn và kết nối những trải nghiệm thành một tổng thể. Khép lại một chặng đường cũng cần được ghi nhận.','Bạn đã đi được đến đâu, và điều gì đáng được công nhận trước chặng mới?']
];
const cups = [
['Át Cốc','Mở lòng · Cảm xúc','Chiếc cốc tràn nước gợi một nguồn cảm xúc, sự quan tâm hoặc cảm hứng vừa mở ra.','Bạn muốn dành chỗ cho cảm xúc hay kết nối mới nào?'],
['Hai Cốc','Tương hỗ · Gặp gỡ','Hai người trao cốc gợi sự gặp nhau trên tinh thần tôn trọng và có đi có lại.','Mối liên hệ này cần sự trao đổi rõ ràng nào từ cả hai phía?'],
['Ba Cốc','Cộng đồng · Chia vui','Ba người nâng cốc gợi sự nâng đỡ từ bạn bè, đồng đội và niềm vui được chia sẻ.','Ai là người bạn có thể tìm đến để chia sẻ thật lòng?'],
['Bốn Cốc','Chững lại · Xem xét','Người ngồi dưới cây chưa đón chiếc cốc được đưa tới gợi sự khép lại hoặc cần thời gian xét lại nhu cầu.','Bạn đang thật sự cần nghỉ, hay bỏ qua một khả năng vì mất hứng?'],
['Năm Cốc','Tiếc nuối · Phần còn lại','Ba cốc đổ và hai cốc còn đứng gợi mất mát được cảm nhận cùng những điều vẫn còn.','Sau khi cho mình thời gian buồn, bạn còn có thể dựa vào điều gì?'],
['Sáu Cốc','Ký ức · Sự dịu dàng','Những chiếc cốc có hoa gợi ký ức, lòng tốt và điều thân thuộc. Quá khứ có thể nâng đỡ mà không cần trở thành nơi ở mãi.','Bạn muốn mang điều tốt đẹp nào từ quá khứ vào hiện tại?'],
['Bảy Cốc','Khả năng · Phân định','Nhiều chiếc cốc với hình ảnh khác nhau gợi các lựa chọn và sức hút của tưởng tượng.','Bạn cần tiêu chí nào để phân biệt mong muốn với lựa chọn khả thi?'],
['Tám Cốc','Rời đi · Tìm ý nghĩa','Nhân vật quay lưng với các cốc gợi việc nhận ra điều đang có chưa đáp ứng nhu cầu sâu hơn.','Điều gì không còn đủ với bạn, và bạn muốn tìm thêm điều gì?'],
['Chín Cốc','Hài lòng · Mong muốn','Người ngồi trước chín cốc gợi niềm vui và sự hài lòng cá nhân. Lá bài mời xem thành tựu có thật sự đáp ứng nhu cầu của mình.','Bạn muốn điều này vì bản thân hay vì hình ảnh nó tạo ra?'],
['Mười Cốc','Gắn bó · Hạnh phúc chung','Cầu vồng cốc trên gia đình gợi cảm giác thuộc về và sự hòa hợp được cùng vun đắp.','Một cuộc sống đủ đầy trong mắt bạn gồm những mối quan hệ như thế nào?'],
['Tiểu đồng Cốc','Tò mò · Nhạy cảm','Con cá trong cốc gợi một cảm xúc hoặc ý tưởng bất ngờ, cần được đón nhận với tò mò.','Nếu không vội chê mình, bạn muốn thử bày tỏ điều gì?'],
['Kỵ sĩ Cốc','Lý tưởng · Bày tỏ','Kỵ sĩ mang cốc gợi sự theo đuổi điều có ý nghĩa bằng cảm xúc và trí tưởng tượng.','Bạn có thể biến thiện ý thành hành động rõ ràng nào?'],
['Hoàng hậu Cốc','Thấu cảm · Lắng nghe','Người nhìn chiếc cốc bên bờ nước gợi khả năng chăm sóc đời sống cảm xúc và lắng nghe.','Bạn có thể quan tâm người khác mà vẫn giữ ranh giới cho mình thế nào?'],
['Vua Cốc','Điềm tĩnh · Điều hòa','Ngai giữa mặt nước gợi khả năng giữ vững khi cảm xúc chuyển động.','Cách đáp lại nào vừa tôn trọng cảm xúc vừa phù hợp với điều bạn muốn xây dựng?']
];
const pentacles = [
['Át Tiền','Cơ hội · Nền tảng','Đồng tiền trong bàn tay gợi một cơ hội thực tế cần được chăm bón và kiểm tra.','Bước nhỏ hữu hình nào có thể biến ý tưởng thành thứ bạn thử được?'],
['Hai Tiền','Linh hoạt · Ưu tiên','Hai đồng tiền được tung giữ gợi việc điều phối nguồn lực giữa nhiều việc.','Bạn đang giữ quá nhiều việc cùng lúc, và có thể bớt điều gì?'],
['Ba Tiền','Tay nghề · Hợp tác','Người thợ và những người cùng bàn bạc gợi chất lượng đến từ chuyên môn và phối hợp.','Bạn cần đóng góp hoặc hỗ trợ chuyên môn nào để làm việc tốt hơn?'],
['Bốn Tiền','Giữ gìn · Kiểm soát','Nhân vật ôm chặt đồng tiền gợi nhu cầu bảo toàn và nỗi sợ mất thứ đang có.','Bạn đang bảo vệ một nhu cầu thật hay cố kiểm soát mọi bất định?'],
['Năm Tiền','Thiếu thốn · Tìm hỗ trợ','Hai người đi trong tuyết cạnh cửa sổ sáng gợi cảm giác thiếu nguồn lực hoặc bị bỏ lại.','Nguồn hỗ trợ thực tế nào bạn chưa thử tìm đến?'],
['Sáu Tiền','Cho nhận · Cân bằng','Cán cân và đồng tiền được trao gợi mối quan hệ giữa hỗ trợ, quyền lực và sự công bằng.','Sự trao đổi hiện tại có rõ ràng và tôn trọng cả hai phía không?'],
['Bảy Tiền','Kiên nhẫn · Đánh giá','Người ngắm thành quả đang lớn gợi việc dừng lại để xem công sức có đi đúng hướng.','Bạn cần quan sát dấu hiệu nào để biết nên tiếp tục hay điều chỉnh?'],
['Tám Tiền','Luyện tập · Chất lượng','Người thợ làm từng đồng tiền gợi tiến bộ nhờ thực hành có chủ đích.','Kỹ năng cụ thể nào đáng để bạn luyện đều trong thời gian tới?'],
['Chín Tiền','Tự chủ · Thành quả','Khu vườn và người đứng trong đó gợi thành quả của sự bền bỉ và khả năng tự lo cho mình.','Bạn có thể ghi nhận công sức của mình theo cách nào?'],
['Mười Tiền','Bền vững · Di sản','Nhiều thế hệ trong một không gian gợi nền tảng chung và tác động dài hạn.','Điều bạn đang xây có thể nâng đỡ bản thân và người khác về lâu dài thế nào?'],
['Tiểu đồng Tiền','Học hỏi · Bắt đầu','Ánh nhìn chăm chú vào đồng tiền gợi tinh thần học qua thực hành và xây nền tảng.','Bạn có thể bắt đầu học điều này bằng một bài tập nhỏ nào?'],
['Kỵ sĩ Tiền','Bền bỉ · Trách nhiệm','Con ngựa đứng vững gợi bước tiến chậm, có kế hoạch và đáng tin cậy.','Thói quen nào giúp bạn tiến đều mà không cần chờ có hứng?'],
['Hoàng hậu Tiền','Chăm sóc · Thực tế','Ngai trong khu vườn gợi sự chăm sóc bằng thời gian, không gian và nguồn lực cụ thể.','Bạn cần chăm sóc nhu cầu đời thường nào trước khi làm thêm?'],
['Vua Tiền','Vững vàng · Quản trị','Ngai giữa những biểu tượng thành quả gợi khả năng quản lý và duy trì nguồn lực.','Bạn cần hệ thống nào để những gì đã xây có thể duy trì bền vững?']
];
const swords = [
['Át Kiếm','Sáng rõ · Sự thật','Thanh kiếm hướng lên gợi một nhận thức mới và sự rõ ràng trong suy nghĩ.','Điều gì cần được gọi tên thẳng thắn và chính xác hơn?'],
['Hai Kiếm','Lưỡng lự · Thông tin','Hai thanh kiếm chéo và khăn bịt mắt gợi sự do dự giữa những lựa chọn khó.','Bạn đang thiếu dữ kiện hay đang tránh một điều mình đã biết?'],
['Ba Kiếm','Tổn thương · Thành thật','Trái tim và ba thanh kiếm gợi nỗi đau cần được thừa nhận thay vì vội giải thích.','Bạn cần nói thật với mình điều gì về cảm giác đang có?'],
['Bốn Kiếm','Nghỉ ngơi · Hồi sức','Nhân vật nằm yên gợi khoảng nghỉ để phục hồi và sắp xếp suy nghĩ.','Bạn có thể tạo một khoảng nghỉ có ranh giới rõ ràng như thế nào?'],
['Năm Kiếm','Xung đột · Cái giá','Người giữ kiếm và những người rời đi gợi chiến thắng có thể làm tổn hại quan hệ.','Điều gì quan trọng hơn việc thắng trong cuộc tranh luận này?'],
['Sáu Kiếm','Chuyển tiếp · Bớt nặng','Con thuyền đi sang bờ khác gợi một chuyển tiếp có thể còn mang theo buồn và hành lý cũ.','Điều gì sẽ làm bước chuyển tiếp này nhẹ hơn một chút?'],
['Bảy Kiếm','Chiến lược · Minh bạch','Nhân vật mang kiếm rời trại gợi cách đi riêng, kín đáo hoặc tránh đối diện. Lá bài không chứng minh ai đang lừa dối.','Bạn đang cần sự riêng tư hợp lý hay đang né một cuộc trao đổi cần thiết?'],
['Tám Kiếm','Bế tắc · Góc nhìn','Nhân vật bị trói giữa những thanh kiếm gợi cảm giác ít lựa chọn và những giới hạn cần phân biệt.','Đâu là trở ngại thực tế, đâu là giả định bạn có thể kiểm tra?'],
['Chín Kiếm','Lo âu · Suy nghĩ','Nhân vật thức trong đêm gợi những suy nghĩ lặp lại và điều đang đè nặng. Lá bài không xác nhận điều lo sợ sẽ xảy ra.','Bạn có thể chia sẻ nỗi lo với ai hoặc viết rõ nó ra thế nào?'],
['Mười Kiếm','Chạm giới hạn · Khép lại','Khung cảnh kết thúc và chân trời sáng gợi việc nhận ra một cách làm đã đi tới giới hạn. Đây không phải dự báo tổn hại thân thể.','Bạn cần ngừng gánh thêm điều gì và tìm hỗ trợ ở đâu?'],
['Tiểu đồng Kiếm','Tìm hiểu · Chất vấn','Nhân vật cầm kiếm giữa gió gợi sự tỉnh táo, tò mò và nhu cầu kiểm chứng.','Câu hỏi nào sẽ giúp bạn hiểu tình huống chính xác hơn?'],
['Kỵ sĩ Kiếm','Quyết liệt · Tốc độ','Kỵ sĩ lao tới gợi năng lượng theo đuổi mục tiêu nhưng cũng nhắc xem lại hệ quả của sự vội vàng.','Bạn cần kiểm tra điều gì trước khi hành động ngay?'],
['Hoàng hậu Kiếm','Rõ ràng · Ranh giới','Thanh kiếm thẳng và bàn tay mở gợi sự minh bạch, độc lập và khả năng nghe mà vẫn giữ tiêu chuẩn.','Bạn có thể nói điều mình cần một cách rõ và tôn trọng thế nào?'],
['Vua Kiếm','Lý trí · Nguyên tắc','Người cầm kiếm trên ngai gợi quyết định dựa vào cấu trúc, bằng chứng và trách nhiệm.','Tiêu chí nhất quán nào sẽ giúp bạn đánh giá các lựa chọn?']
];
const wands = [
['Át Gậy','Cảm hứng · Khởi động','Cành cây đâm chồi gợi một nguồn hứng khởi muốn thành hành động.','Bạn có thể thử ý tưởng này ở quy mô nhỏ nào?'],
['Hai Gậy','Tầm nhìn · Chuẩn bị','Nhân vật nhìn xa với quả cầu gợi việc mở rộng khả năng và chuẩn bị bước ra ngoài điều quen thuộc.','Hướng đi nào đáng để bạn tìm hiểu kỹ hơn trước khi chọn?'],
['Ba Gậy','Mở rộng · Chờ đợi','Nhân vật nhìn những con thuyền gợi việc đã bắt đầu và đang quan sát phản hồi từ thế giới.','Bạn đang chờ tín hiệu nào, và có thể chủ động làm gì trong lúc chờ?'],
['Bốn Gậy','Nền tảng · Ăn mừng','Cổng hoa và những người đón chào gợi một cột mốc, cộng đồng và cảm giác có chỗ đứng.','Cột mốc nhỏ nào xứng đáng được bạn và những người liên quan ghi nhận?'],
['Năm Gậy','Va chạm · Khác biệt','Nhiều người cầm gậy gợi năng lượng cạnh tranh hoặc ý kiến chưa phối hợp.','Khác biệt nào cần được làm rõ để cả nhóm bớt giẫm chân nhau?'],
['Sáu Gậy','Ghi nhận · Tự tin','Vòng nguyệt quế gợi sự công nhận và niềm tin sau nỗ lực.','Bạn có thể đón nhận lời ghi nhận mà vẫn tiếp tục học hỏi thế nào?'],
['Bảy Gậy','Giữ lập trường · Áp lực','Nhân vật trên cao đối diện nhiều gậy gợi việc bảo vệ vị trí hoặc điều mình tin.','Điều gì đáng để bạn giữ vững, và điều gì không cần tranh đấu?'],
['Tám Gậy','Chuyển động · Kịp thời','Những cây gậy bay cùng hướng gợi nhịp độ tăng nhanh và sự phối hợp.','Bạn cần làm rõ ưu tiên nào khi mọi thứ diễn ra nhanh?'],
['Chín Gậy','Bền gan · Giới hạn','Nhân vật băng đầu cạnh hàng gậy gợi sự kiên trì cùng nhu cầu bảo vệ sức lực.','Bạn cần ranh giới hoặc hỗ trợ nào để không chỉ cố chịu đựng?'],
['Mười Gậy','Gánh nặng · Phân chia','Người ôm bó gậy gợi trách nhiệm tích tụ và cái giá của việc tự gánh hết.','Việc nào có thể bỏ, chia sẻ hoặc làm đơn giản hơn?'],
['Tiểu đồng Gậy','Khám phá · Hào hứng','Nhân vật nhìn cây gậy gợi tinh thần thử nghiệm và học từ trải nghiệm mới.','Bạn tò mò điều gì mà chưa cần phải giỏi ngay?'],
['Kỵ sĩ Gậy','Dấn bước · Nhiệt huyết','Con ngựa chuyển động gợi tinh thần phiêu lưu và hành động mạnh mẽ.','Bạn muốn tiến nhanh nhưng cần cam kết nào để không bỏ dở?'],
['Hoàng hậu Gậy','Tự tin · Sức hút','Hoa hướng dương và dáng ngồi mở gợi sự ấm áp, độc lập và khả năng truyền cảm hứng.','Bạn muốn thể hiện điều gì của mình một cách tự nhiên hơn?'],
['Vua Gậy','Tầm nhìn · Dẫn dắt','Người giữ gậy trên ngai gợi khả năng nhìn xa và dẫn dắt hành động chung.','Tầm nhìn của bạn cần được chuyển thành lời mời hoặc bước đi cụ thể nào?']
];
import images from './card-images.json';
export type Card = { id:number; name:string; vn:string; keywords:string; meaning:string; question:string; image:string; source:string; suit:string };
const rows = [...major,...cups,...pentacles,...swords,...wands];
export const cards:Card[] = images.map((c,i)=>({ ...c, vn:rows[i][0],keywords:rows[i][1],meaning:rows[i][2],question:rows[i][3],suit:i<22?'Ẩn Chính':i<36?'Cốc':i<50?'Tiền':i<64?'Kiếm':'Gậy'}));
export const positions=['Tình huống hiện tại','Điều cần nhìn rõ','Hướng đi cân nhắc'];
