import assert from 'node:assert/strict';
import {shuffle,hashDeck,safety,randomInt} from '../lib/session';
import {cards} from '../lib/meanings';
assert.equal(cards.length,78);assert.equal(new Set(cards.map(c=>c.name)).size,78);
assert(cards.every(c=>c.meaning&&c.question&&c.vn));
for(let n=0;n<100;n++){const d=shuffle();assert.equal(new Set(d).size,78);assert(d.every(x=>x>=0&&x<78));assert(randomInt(78)<78)}
const d=shuffle(),h=await hashDeck(d,'test');assert.equal(h,await hashDeck([...d],'test'));[d[0],d[1]]=[d[1],d[0]];assert.notEqual(h,await hashDeck(d,'test'));
assert.equal(safety('Mình muốn tự tử'),'crisis');assert.equal(safety('Tôi có mang thai không?'),'professional');assert.equal(safety('Mình muốn học một kỹ năng mới'),null);
console.log('PASS: 78 unique cards, shuffle permutations/range, immutable commitment, safety examples.');
