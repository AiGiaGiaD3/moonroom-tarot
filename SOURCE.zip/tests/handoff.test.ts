import assert from 'node:assert/strict';
import {buildHandoff} from '../lib/handoff';
import type {Session} from '../lib/session';
const s:Session={id:'test',date:'2026-11-09',topic:'Tổng quan',context:'PRIVATE_CONTEXT',question:'PRIVATE_QUESTION',observation:'PRIVATE_OBSERVATION',deck:Array.from({length:78},(_,i)=>i),picked:[0,17,77],revealed:[0,1,2],note:'PRIVATE_NOTE',action:'PRIVATE_ACTION',reading:'PRIVATE_IMPORTED_READING',commitment:'',nonce:'',messages:[]};
const off=buildHandoff(s,{question:false,context:false,observation:false});for(const value of [s.context,s.question,s.observation,s.note,s.action,s.reading])assert(!off.includes(value));
const q=buildHandoff(s,{question:true,context:false,observation:false});assert(q.includes(s.question));assert(!q.includes(s.context)&&!q.includes(s.observation));
const all=buildHandoff(s,{question:true,context:true,observation:true});assert(all.includes(s.context)&&all.includes(s.question)&&all.includes(s.observation));assert(!all.includes(s.note));
const data=JSON.parse(off.split('DỮ LIỆU TRẢI BÀI\n')[1]);assert.deepEqual(data.cac_la_bai.map((c:any)=>c.ten),['The Fool','The Star','King of Wands']);assert(data.cac_la_bai.every((c:any)=>c.chieu==='Xuôi'));
console.log('PASS: private fields opt-in; journal excluded; exact three upright cards preserved.');
